module.exports = async function (context) {
  return {
    status: 200,
    body: "<h1>FELIZ NAVIDAD!!</h1>",
    headers: {
      "content-type": "text/html",
    },
  };
};
